-- 活动数据
INSERT INTO `xypm_activity` VALUES (1, '吃西瓜大赛，邀所有业主一起参与!', '/app/xypm/imgs/home-b3.png', 1692979200, 1701360000, 1701478800, 1704099600, '湖南行云网络科技有限公司', 2, 2, '湖南省/长沙市/天心区', '未来云9013', '<p>吃西瓜大赛，邀所有业主一起参与!<span style=\"text-wrap:wrap;\">吃西瓜大赛，邀所有业主一起参与!</span></p><p>&nbsp; <img src=\"/app/xypm/imgs/home-b3.png\" alt=\"\" /></p>', 243, 1, 'normal', 1693015327, 1693820689, NULL);
INSERT INTO `xypm_activity` VALUES (2, '缴物业费即可参与抽奖，先到先得哦', '/app/xypm/imgs/home-b2.png', 1693015560, 1704074760, 1704161160, 1709258760, '湖南行云网络科技有限公司', 200, 2, '湖南省/株洲市/天元区', '未来云9013', '<p>缴物业费即可参与抽奖，先到先得哦!缴物业费即可参与抽奖，先到先得哦!</p><p><img src=\"/app/xypm/imgs/home-b2.png\" alt=\"\" /></p>', 51, 4, 'normal', 1693015661, 1693032931, NULL);

-- 商品分类
INSERT INTO `xypm_category` VALUES (1, '优惠好物', '', 'goods', '', 0, 193, 'normal', 1688528248, 1688528248);
INSERT INTO `xypm_category` VALUES (2, '家政服务', '', 'goods', '', 0, 195, 'normal', 1693279119, 1693279119);

-- 商品数据
INSERT INTO `xypm_goods` VALUES (1, '大肚杯男女通用新款大容量水杯', '送货上门,好物精选,价格实惠', '1', '/app/xypm/imgs/goods.png', '/app/xypm/imgs/goods.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">水杯大肚杯女新款大容量水杯、推荐给您。</p><p style=\"text-align:center;\"><br /></p><p><img src=\"/app/xypm/imgs/goods.png\" alt=\"\" /></p>', '29.9起', 59.90, '1', 0, 14, 0, 0, NULL, NULL, 0, 'up', 1688032211, 1693965666, NULL);
INSERT INTO `xypm_goods` VALUES (2, '家用客厅卧室厨房厕所卫生间大容量垃圾桶', '送货上门,好物精选,价格实惠', '1', '/app/xypm/imgs/goods.png', '/app/xypm/imgs/goods.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">家用客厅卧室厨房厕所卫生间大容量垃圾桶</p><p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\"><img src=\"/app/xypm/imgs/goods.png\" alt=\"\" /></p>', '9.9', 19.90, '0', 0, 0, 0, 0, NULL, NULL, 0, 'up', 1693965857, 1693965857, NULL);
INSERT INTO `xypm_goods` VALUES (3, '成人儿童整牙戴牙套软毛小头牙刷', '送货上门,好物精选,价格实惠', '1', '/app/xypm/imgs/goods.png', '/app/xypm/imgs/goods.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">成人儿童整牙戴牙套软毛小头牙刷</p><p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\"><img src=\"/app/xypm/imgs/goods.png\" alt=\"\" /></p>', '9.9', 19.90, '0', 0, 0, 0, 0, NULL, NULL, 0, 'up', 1693966031, 1693966031, NULL);
INSERT INTO `xypm_goods` VALUES (4, '小学生专用一二年级三角粗铅笔', '送货上门,好物精选,价格实惠', '1', '/app/xypm/imgs/goods.png', '/app/xypm/imgs/goods.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">小学生专用一二年级三角粗铅笔</p><p style=\"text-align:center;\"><br /></p><p><img src=\"/app/xypm/imgs/goods.png\" alt=\"\" /></p>', '9.9', 19.90, '0', 0, 0, 0, 0, NULL, NULL, 0, 'up', 1693966269, 1693966269, NULL);
INSERT INTO `xypm_goods` VALUES (5, '窗帘干洗上门服务套餐', '上门服务,价格实惠', '2', '/app/xypm/imgs/goods1.png', '/app/xypm/imgs/goods1.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">窗帘干洗上门服务套餐</p><p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\"><img src=\"/app/xypm/imgs/goods1.png\" alt=\"\" /></p>', '299起', 399.00, '1', 0, 15, 0, 0, NULL, NULL, 0, 'up', 1693966764, 1693966764, NULL);
INSERT INTO `xypm_goods` VALUES (6, '家政服务地毯清洗服务套餐', '上门服务,价格实惠', '2', '/app/xypm/imgs/goods3.png', '/app/xypm/imgs/goods3.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">家政服务地毯清洗服务套餐</p><p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\"><img src=\"/app/xypm/imgs/goods3.png\" alt=\"\" /></p><p><img src=\"家政服务地毯清洗服务套餐\" alt=\"\" /></p>', '50起', 99.00, '1', 0, 21, 4, 0, NULL, NULL, 0, 'up', 1693967567, 1693967567, NULL);
INSERT INTO `xypm_goods` VALUES (7, '物业深度保养木地板打蜡上门服务', '上门服务,价格实惠', '2', '/app/xypm/imgs/goods2.png', '/app/xypm/imgs/goods2.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">物业深度保养木地板打蜡上门服务</p><p style=\"text-align:center;\"><br /></p><p><img src=\"物业深度保养木地板打蜡上门服务\" alt=\"\" /><img src=\"/app/xypm/imgs/goods2.png\" alt=\"\" /></p>', '15起', 29.90, '1', 0, 3, 0, 0, NULL, NULL, 0, 'up', 1693968006, 1693968006, NULL);
INSERT INTO `xypm_goods` VALUES (8, '厨房厕所管道疏通上门服务', '上门服务,价格实惠', '2', '/app/xypm/imgs/goods4.png', '/app/xypm/imgs/goods4.png', '<p style=\"text-align:center;\"><br /></p><p style=\"text-align:center;\">厨房厕所管道疏通上门服务</p><p style=\"text-align:center;\"><br /></p><p><img src=\"/app/xypm/imgs/goods4.png\" alt=\"\" /></p>', '80', 99.00, '0', 0, 2, 0, 0, NULL, NULL, 0, 'up', 1693968255, 1693968255, NULL);

INSERT INTO `xypm_goods_sku` VALUES (1, '规格', 0, 1, 0);
INSERT INTO `xypm_goods_sku` VALUES (2, '500ML', 1, 1, 0);
INSERT INTO `xypm_goods_sku` VALUES (3, '800ML', 1, 1, 0);
INSERT INTO `xypm_goods_sku` VALUES (4, '房型', 0, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (5, ' 两房一厅', 4, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (6, '三房两厅', 4, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (7, '四房两厅', 4, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (8, '五房两厅', 4, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (9, '别野', 4, 5, 0);
INSERT INTO `xypm_goods_sku` VALUES (10, '规格', 0, 6, 0);
INSERT INTO `xypm_goods_sku` VALUES (11, '10平方', 10, 6, 0);
INSERT INTO `xypm_goods_sku` VALUES (12, '50平方', 10, 6, 0);
INSERT INTO `xypm_goods_sku` VALUES (13, '100平方', 10, 6, 0);
INSERT INTO `xypm_goods_sku` VALUES (14, '尺寸', 0, 7, 0);
INSERT INTO `xypm_goods_sku` VALUES (15, '1平方', 14, 7, 0);
INSERT INTO `xypm_goods_sku` VALUES (16, '50平方', 14, 7, 0);
INSERT INTO `xypm_goods_sku` VALUES (17, '100平方', 14, 7, 0);

INSERT INTO `xypm_goods_sku_price` VALUES (1, '2', 1, '', 100, 0, '', 29.90, '500ML', 0.20, 1, 'up', 1693965666, 1693965666, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (2, '3', 1, '', 100, 0, '', 39.90, '800ML', 0.30, 2, 'up', 1693965666, 1693965666, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (3, NULL, 2, NULL, 1000, 0, '', 9.90, NULL, 0.00, 3, 'up', 1693965857, 1693965857, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (4, NULL, 3, NULL, 1000, 0, '', 9.90, NULL, 0.00, 43, 'up', 1693966031, 1693966031, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (5, NULL, 4, NULL, 1000, 0, '', 9.90, NULL, 0.00, 44, 'up', 1693966269, 1693966269, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (6, '5', 5, '', 1000, 0, '', 299.00, ' 两房一厅', 1.00, 45, 'up', 1693967216, 1693967216, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (7, '6', 5, '', 1000, 0, '', 399.00, '三房两厅', 1.00, 46, 'up', 1693967216, 1693967216, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (8, '7', 5, '', 1000, 0, '', 499.00, '四房两厅', 1.00, 47, 'up', 1693967216, 1693967216, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (9, '8', 5, '', 1000, 0, '', 599.00, '五房两厅', 1.00, 48, 'up', 1693967216, 1693967216, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (10, '9', 5, '', 1000, 0, '', 999.00, '别野', 1.00, 49, 'up', 1693967216, 1693967216, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (11, '11', 6, '', 1000, 0, '', 50.00, '10平方', 1.00, 50, 'up', 1693967796, 1693967796, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (12, '12', 6, '', 1000, 0, '', 229.00, '50平方', 1.00, 51, 'up', 1693967796, 1693967796, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (13, '13', 6, '', 1000, 0, '', 4800.00, '100平方', 1.00, 52, 'up', 1693967796, 1693967796, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (14, '15', 7, '', 1000, 0, '', 15.00, '1平方', 1.00, 53, 'up', 1693968180, 1693968180, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (15, '16', 7, '', 1000, 0, '', 699.00, '50平方', 1.00, 54, 'up', 1693968180, 1693968180, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (16, '17', 7, '', 1000, 0, '', 1299.00, '100平方', 1.00, 55, 'up', 1693968180, 1693968180, NULL);
INSERT INTO `xypm_goods_sku_price` VALUES (17, NULL, 8, NULL, 1000, 0, '', 80.00, NULL, 0.00, 56, 'up', 1693968255, 1693968255, NULL);

-- 公告数据
INSERT INTO `xypm_notice` VALUES (1, '暴雨致房屋漏水、车库被淹，业主的损失谁买单？', '/app/xypm/imgs/logo.jpg', '入伏以来，各地暴雨接踵而至，防汛防涝的新闻分分钟引入眼帘，除了道路积水，行人遇险、城市排水系统瘫痪、群众受灾等这种公共灾害以外，还有一种伤害是购房者比较关注的，那就是暴雨过后，房屋漏水或者被淹，地下车库进水汽车损毁等财物受到损失的状况，谁该为业主的损失买单呢？<br /><br /><p>一般来讲因天灾造成的损失，属于不可抗力，。但也有一些损失，原本是可以避免的，在这种情况下，应有人对业主的损失进行赔偿。</p>', 15, 3, 'normal', 1596684772, 1694417728, NULL);
INSERT INTO `xypm_notice` VALUES (2, '2023年9月1号上午9点到下午5点停气通知', '/app/xypm/imgs/logo.jpg', '各位住户燃气公司的停气通知请仔细阅读哦.', 5, 1, 'normal', 1623222438, 1694417741, NULL);
INSERT INTO `xypm_notice` VALUES (3, '天然气用气安全防范通知', '/app/xypm/imgs/logo.jpg', '<p>各位业主/住户请自行排查家里的燃气热水器和灶具:&nbsp;</p><p>1、燃气热水器和灶具超过8年使用寿命的请更换！&nbsp;</p><p>2、不带自动熄火装置的灶具请更换！</p><p>3、直排热水器请停止使用！</p>', 5, 2, 'normal', 1623723309, 1694417735, NULL);

INSERT INTO `xypm_article` VALUES (1, '用户协议', '', '<p>用户协议<br></p>', 1, 'normal', 1705025625, 1705025625);
INSERT INTO `xypm_article` VALUES (2, '隐私政策', '', '<p>隐私政策<br></p>', 2, 'normal', 1705025639, 1705025639);
