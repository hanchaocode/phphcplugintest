<?php

return [
    'Id'            => 'ID',
    'Name'          => '名称',
    'Type'          => '类型',
    'Type shop'     => '商铺',
    'Type parking'  => '车位',
    'Remark'        => '备注',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Createtime'    => '添加时间',
    'Updatetime'    => '更新时间'
];
