<?php

return [
    'User_id'   => '用户',
    'Type'      => '类型',
    'Target_id' => '目标ID'
];
