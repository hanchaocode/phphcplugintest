<?php

return [
    'Id'          => 'ID',
    'Type'        => '页面类型',
    'Type store'  => '门店',
    'Type course' => '课程',
    'Title'       => '页面标题',
    'Route'       => '路径',
    'Weigh'       => '权重',
    'Status'      => '状态',
    'Basic'       => '基础链接',
    'User'        => '会员中心',
    'Notice'      => '公告链接',
    'Activity'    => '活动链接',
    'Goods'       => '商品链接',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
];
