<?php

return [
    'Name'    => '变量名',
    'Title'   => '变量标题',
    'Tip'     => '变量描述',
    'Type'    => '类型:string,text,int,bool,array,datetime,date,file',
    'Value'   => '变量值',
    'Content' => '变量字典数据',
    'Rule'    => '验证规则',
    'Extend'  => '扩展属性'
];
