<?php

return [
    'Id'         => 'ID',
    'User_id'    => '用户',
    'Type'       => '类型',
    'Target_id'  => '目标ID',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间'
];
