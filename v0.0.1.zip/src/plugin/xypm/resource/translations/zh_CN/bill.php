<?php

return [
    'Id'                => 'ID',
    'Member_id'         => '缴费成员',
    'Bill_order_id'     => '缴费订单ID',
    'Build_id'          => '对应房产ID',
    'Buildname'         => '名称',
    'Buildtype'         => '房产类型',
    'Buildtype house'   => '房屋',
    'Buildtype shop'    => '商铺',
    'Buildtype parking' => '车位',
    'Buildtype garage'  => '储物间',
    'Billdate'          => '账单日期',
    'Cycle'             => '交费周期',
    'Money'             => '费用',
    'Status'            => '状态',
    'Status 1'          => '已交费',
    'Set status to 1'   => '设为已交费',
    'Status 0'          => '待交费',
    'Set status to 0'   => '设为待交费',
    'Createtime'        => '生成时间',
    'Updatetime'        => '更新时间'
];
