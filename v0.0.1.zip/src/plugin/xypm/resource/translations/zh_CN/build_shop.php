<?php

return [
    'Id'            => 'ID',
    'Build_area_id' => '商铺区域',
    'Number'        => '商铺编号',
    'Buildarea'  => '建筑面积',
    'Ownername'  => '户主姓名',
    'Mobile'     => '户主电话',
    'Billdate'    => '开始收费日期',
    'Floor'         => '所在楼层',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status 1'      => '已绑定户主',
    'Set status to 1'=> '设为已绑定户主',
    'Status 0'      => '未绑定户主',
    'Set status to 0'=> '设为未绑定户主',
    'Createtime'    => '添加时间',
    'Updatetime'    => '更新时间'
];
