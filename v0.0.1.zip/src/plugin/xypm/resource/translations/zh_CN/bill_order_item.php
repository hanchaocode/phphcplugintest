<?php

return [
    'Id'            => 'ID',
    'Bill_order_id' => '交费订单',
    'Bill_id'       => '账单',
    'Cycle'         => '交费周期',
    'Billdate'      => '账单日期',
    'Money'         => '费用',
    'Createtime'    => '添加时间',
    'Updatetime'    => '更新时间'
];
