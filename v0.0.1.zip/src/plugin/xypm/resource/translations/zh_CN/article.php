<?php

return [
    'Id'         => 'ID',
    'Title'      => '标题',
    'Image'      => '图片',
    'Content'    => '内容',
    'Views'      => '浏览量',
    'Weigh'      => '权重',
    'Status'     => '状态',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
