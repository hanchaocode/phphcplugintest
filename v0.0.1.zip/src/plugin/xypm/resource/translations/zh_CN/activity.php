<?php

return [
    'Id'                => 'ID',
    'Title'             => '标题',
    'Image'             => '封面图',
    'Signup_start_time' => '报名开始时间',
    'Signup_end_time'   => '报名结束时间',
    'Start_time'        => '活动开始时间',
    'End_time'          => '活动结束时间',
    'Organizer'         => '主办单位',
    'Number'            => '活动人数',
    'Signup_num'            => '已报名人数',
    'City'              => '省市区',
    'Address'           => '详细地址',
    'Content'           => '活动内容',
    'Views'             => '浏览量',
    'Weigh'             => '权重',
    'Status'            => '状态',
    'Status normal'     => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden'     => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间'
];
