<?php

return [
    'Id'             => 'ID',
    'Goods_id'       => '所属产品',
    'Image'          => '缩略图',
    'Stock'          => '库存',
    'Sales'          => '已售',
    'Sn'             => '货号',
    'Price'          => '价格',
    'Goods_sku_text' => '规格',
    'Weigh'          => '排序',
    'Status'         => '状态'
];
