<?php

return [
    'Id'         => 'ID',
    'User_id'    => '用户',
    'Buildname'  => '房产',
    'Realname'   => '姓名',
    'Mobile'     => '电话',
    'Content'    => '内容',
    'Images'     => '图片',
    'Status'     => '状态',
    'Status 0'   => '待处理',
    'Set status to 0'=> '设为待处理',
    'Status 1'   => '处理中',
    'Set status to 1'=> '设为处理中',
    'Status 2'   => '已处理',
    'Set status to 2'=> '设为已处理',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间'
];
