
?php

return [
    'Id'         => 'ID',
    'User_id'    => '会员',
    'Type'       => '变更类型',
    'Money'      => '变更费用',
    'Before'     => '变更前',
    'After'      => '变更后',
    'Sys'        => '后台操作',
    'Pay_goods'  => '购买商品',
    'Pay_bill'  => '交物业费',
    'Service_id' => '业务ID',
    'Remark'     => '备注',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
