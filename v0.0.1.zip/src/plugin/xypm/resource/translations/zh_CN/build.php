<?php

return [
    'Id'                => 'ID',
    'Name'              => '楼宇名称',
    'Unitnum'           => '单元数量',
    'Floornum'          => '楼宇层数',
    'Roomnum'           => '房屋数量',
    'Weigh'             => '权重',
    'Status'            => '楼宇类型',
    'Status high'       => '高层',
    'Set status to high'=> '设为高层',
    'Status multilayer' => '多层',
    'Set status to multilayer'=> '设为多层',
    'Status villa'      => '别墅',
    'Set status to villa'=> '设为别墅',
    'Createtime'        => '添加时间',
    'Updatetime'        => '更新时间'
];
