<?php

return [
    'Id'                 => 'ID',
    'User_id'            => '用户',
    'Type'         => '房产类型',
    'Type house'   => '房屋',
    'Type shop'    => '商铺',
    'Type parking' => '车位',
    'Type garage'  => '储物间',
    'Build_id'           => '房产',
    'Is_default'         => '默认',
    'Createtime'         => '创建时间',
    'Updatetime'         => '更新时间'
];
