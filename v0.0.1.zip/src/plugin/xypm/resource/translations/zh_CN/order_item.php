<?php

return [
    'Id'                 => 'ID',
    'Goods_order_id'     => ' 商品订单',
    'Goods_id'           => '商品',
    'Goods_sku_price_id' => '规格 id',
    'Goods_sku_text'     => '规格名',
    'Goods_title'        => '商品名称',
    'Goods_image'        => '商品图片',
    'Goods_price'        => '商品价格',
    'Buy_num'            => '购买数量',
    'Goods_weight'       => '商品重量',
    'Createtime'         => '添加时间',
    'Updatetime'         => '更新时间',
    'Deletetime'         => '删除时间'
];
