<?php

return [
    'Id'            => 'ID',
    'Title'         => '标题',
    'Image'         => '缩略图',
    'Content'       => '内容',
    'Views'         => '浏览量',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间',
    'Deletetime'    => '删除时间'
];
