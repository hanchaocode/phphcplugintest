<?php

return [
    'Id'       => 'ID',
    'Name'     => '名称',
    'Pid'      => '所属规格',
    'Goods_id' => '产品',
    'Weigh'    => '排序'
];
