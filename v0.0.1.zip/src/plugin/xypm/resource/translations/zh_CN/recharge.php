<?php

return [
    'Id'            => 'ID',
    'Store_id'      => '场馆',
    'Facevalue'     => '面值',
    'Buyprice'      => '售价',
    'Status'        => '状态',
    'Status normal' => '正常',
    'Set status to normal'=> '设为正常',
    'Status hidden' => '隐藏',
    'Set status to hidden'=> '设为隐藏',
    'Remark'          => '套餐说明',
    'Createtime'    => '创建时间',
    'Updatetime'    => '更新时间'
];
