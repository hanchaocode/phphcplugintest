<?php

return [
    'Id'            => 'ID',
    'Build_area_id' => '车位区域',
    'Number'        => '车位编号',
    'Ownername'  => '户主姓名',
    'Billdate'    => '开始收费日期',
    'Mobile'     => '户主电话',
    'Weigh'         => '权重',
    'Status'        => '状态',
    'Status 1'      => '已绑定户主',
    'Set status to 1'=> '设为已绑定户主',
    'Status 0'      => '未绑定户主',
    'Set status to 0'=> '设为未绑定户主',
    'Createtime'    => '添加时间',
    'Updatetime'    => '更新时间'
];
