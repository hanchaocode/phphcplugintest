<?php

return [
    'Id'                => 'ID',
    'Title'             => '标题',
    'Normal'            => '正常',
    'Status normal'     => '正常',
    'Status hidden'     => '隐藏',
    'Hidden'            => '隐藏',
    'Createtime'        => '创建时间',
    'Updatetime'        => '更新时间',
    'Deletetime'        => '删除时间'
];
