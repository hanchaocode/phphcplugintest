<?php

return [
    'Id'          => 'ID',
    'Build_id' => '楼宇',
    'Unit'        => '单元',
    'Floor'       => '楼层',
    'Number'      => '房号',
    'Buildarea'  => '建筑面积',
    'Ownername'  => '户主姓名',
    'Mobile'     => '户主电话',
    'Weigh'       => '权重',
    'Status'      => '状态',
    'Billdate'    => '开始收费日期',
    'Status 1'    => '已绑定户主',
    'Set status to 1'=> '设为已绑定户主',
    'Status 0'    => '未绑定户主',
    'Set status to 0'=> '设为未绑定户主',
    'Createtime'  => '添加时间',
    'Updatetime'  => '更新时间'
];
