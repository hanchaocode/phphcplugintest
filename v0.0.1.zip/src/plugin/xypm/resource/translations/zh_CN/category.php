<?php

return [
    'Id'         => 'ID',
    'Name'       => '名称',
    'Intro'      => '简介',
    'Type'       => '类型',
    'Image'      => '图片',
    'Pid'        => '父类',
    'Weigh'      => '权重',
    'Status'     => '状态',
    'Goods'      => '商品',
    'Course'      => '课程',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间'
];
