<?php

return [
    'Id'         => 'ID',
    'Page_token' => 'Token',
    'Name'       => '名称',
    'Cover'      => '封面',
    'Type'       => '类型',
    'Page'       => '配置',
    'Item'       => '项目',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Deletetime' => '删除时间',
    'Status'     => '状态'
];
