<?php

return [
    'Id'             => 'ID',
    'Title'          => '标题',
    'Category_id'    => '所属分类',
    'Image'          => '商品主图',
    'Images'         => '轮播图',
    'Content'        => '详情',
    'Line_price'     => '划线价格',
    'Price'          => '价格',
    'Is_sku'         => '规格',
    'Stock'          => '库存',
    'Sn'             => '编号',
    'Likes'          => '收藏人数',
    'Views'          => '浏览量',
    'Sales'          => '销量',
    'Status'         => '状态',
    'Status up'      => '上架',
    'Status hidden'  => '隐藏',
    'Status down'    => '下架',
    'Createtime'     => '添加时间',
    'Updatetime'     => '更新时间',
    'Deletetime'     => '删除时间'
];
