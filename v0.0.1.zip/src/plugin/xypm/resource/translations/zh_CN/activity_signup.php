<?php

return [
    'Id'          => 'ID',
    'Title'       => '标题',
    'Activity_id' => '活动',
    'User_id'     => '会员',
    'Realname'    => '姓名',
    'Mobile'      => '电话',
    'Buildname'   => '房产名称',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间'
];
