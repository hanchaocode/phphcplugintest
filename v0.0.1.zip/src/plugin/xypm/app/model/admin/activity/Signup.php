<?php

namespace plugin\xypm\app\model\admin\activity;

use plugin\saiadmin\basic\BaseNormalModel;



class Signup extends BaseNormalModel
{

    

    

    // 表名
    protected $name = 'xypm_activity_signup';
    


    // 定义时间戳字段名
    protected $createTime = 'createtime';
    protected $updateTime = 'updatetime';
    protected $deleteTime = false;

    // 追加属性
    protected $append = [

    ];
    

    







}
