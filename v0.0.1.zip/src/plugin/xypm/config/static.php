<?php

return [
    'enable' => true,
    'middleware' => [],    // Static file Middleware
];
