<?php
return [
    'files' => [
        base_path() . '/plugin/xypm/app/functions.php',
    ]
];